function openTabs(Tabnya) {
  var i, x, tablinks;
  x = document.getElementsByClassName("tabnya");
  for (i = 0; i < x.length; i++) {
      x[i].style.display = "none";
  }
  
  document.getElementById(Tabnya).style.display = "block";
}